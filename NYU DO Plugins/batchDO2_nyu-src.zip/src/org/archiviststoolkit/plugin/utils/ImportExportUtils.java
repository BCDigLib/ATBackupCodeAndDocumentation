package org.archiviststoolkit.plugin.utils;

import org.archiviststoolkit.util.StringHelper;

/**
 * This class contains utility methods use when either exporting or importing files for the creation
 * and linking of Digital Objects to resource components
 *
 * Created by IntelliJ IDEA.
 * User: nathan
 * Date: 4/18/12
 * Time: 2:32 PM
 *
 */
public class ImportExportUtils {

    /**
     * Method to return the index of a particular column
     *
     * @param columnName
     * @param headerLine
     * @return
     */
    public static int getColumnIndex(String columnName, String headerLine) {
        String[] sa = headerLine.split("\\s*\t\\s*");
        int index = -1;

        for(int i = 0; i < sa.length; i++) {
            if(sa[i].equalsIgnoreCase(columnName)) {
                index = i;
                break;
            }
        }

        return index;
    }

    /**
     * Method to return the component title which has been strip of tags, new lines,
     * and truncated to less than 96 characters if needed. A call to this method
     * is need to make sure the tab delimited files being exported are valid
     *
     * @return cleaned up component title
     */
    public static String getSafeTitle(String componentTitle) {
        String safeTitle = "tile";

        // remove any tags and newline characters
        String title = StringHelper.tagRemover(componentTitle.replace("\n", " ")).trim();

        if(title.length() < 96) {
            safeTitle = title;
        } else {
            String titlePart1 = title.substring(0, 61);
            String titlePart2 = title.substring(title.length() - 32);
            safeTitle = titlePart1 + "..." + titlePart2;
        }

        return safeTitle;
    }
}
