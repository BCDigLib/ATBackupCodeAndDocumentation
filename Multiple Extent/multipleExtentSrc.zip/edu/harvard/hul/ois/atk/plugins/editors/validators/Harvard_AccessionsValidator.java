
/**********************************************************************
 * Copyright (c) 2001 by the President and Fellows of Harvard College
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 *
 * Contact information
 *
 * Office for Information Systems
 * Harvard University Library
 * Harvard University
 * Cambridge, MA  02138
 * (617)495-3724
 * hulois@hulmail.harvard.edu
 *
 * This package is based heavily on BYU multiple-extent plugin package for ATK, customized for Harvard University
 *
 */

package edu.harvard.hul.ois.atk.plugins.editors.validators;

import org.archiviststoolkit.model.Accessions;
import org.archiviststoolkit.util.ATPropertyValidationSupport;
import com.jgoodies.validation.ValidationResult;
import com.jgoodies.validation.util.ValidationUtils;

import edu.byu.plugins.editors.validators.BYU_AccessionsValidator;

public class Harvard_AccessionsValidator extends BYU_AccessionsValidator {

	// Instance Creation ******************************************************

	/**
	 * Constructs an validator
	 *
	 * @param accession the accession to be validated
	 */
	public Harvard_AccessionsValidator(Accessions accession) {
		this.objectToValidate = accession;
	}

	public Harvard_AccessionsValidator() {
	}


	// Validation *************************************************************

	/**
	 * Validates this Validator's Order and returns the result
	 * as an instance of {@link com.jgoodies.validation.ValidationResult}.
	 *
	 * @return the ValidationResult of the accession validation
	 */
	public ValidationResult validate() {

		Accessions modelToValidate = (Accessions)objectToValidate;

		ATPropertyValidationSupport support =
				new ATPropertyValidationSupport(modelToValidate, "Accession");

		//modelToValidate number is manditory
		if (ValidationUtils.isBlank(modelToValidate.getAccessionNumber1()))
			support.addError("Accession No", "is mandatory");

		//modelToValidate date is manditory
		if (modelToValidate.getAccessionDate() == null)
			support.addError("Accession Date", "is mandatory");

		//repository is manditory
		if (modelToValidate.getRepository() == null)
			support.addError("Repository", "is mandatory");

		if (modelToValidate.getAccessionDate() != null && ValidationUtils.isFutureDay(modelToValidate.getAccessionDate())) {
			support.addError("Accession date", "can't be in the future");
		}

		if (modelToValidate.getAccessionProcessedDate() != null && ValidationUtils.isFutureDay(modelToValidate.getAccessionProcessedDate())) {
			support.addError("Date processed", "can't be in the future");
		}

		if (modelToValidate.getAcknowledgementDate() != null && ValidationUtils.isFutureDay(modelToValidate.getAcknowledgementDate())) {
			support.addError("Acknowledgement date", "can't be in the future");
		}

		if (modelToValidate.getAgreementSentDate() != null && ValidationUtils.isFutureDay(modelToValidate.getAgreementSentDate())) {
			support.addError("Agreement sent", "can't be in the future");
		}

		if (modelToValidate.getAgreementReceivedDate() != null && ValidationUtils.isFutureDay(modelToValidate.getAgreementReceivedDate())) {
			support.addError("Accession received", "can't be in the future");
		}

		//at least one date record is required
        /*
		if (modelToValidate.getArchDescriptionDates().size() == 0)
			support.addError("At least one date record", "is mandatory");
         */
     
		//at least one date record is required
/*
		if (modelToValidate.getPhysicalDesctiptions().size() == 0)
			support.addError("At least one physical description record", "is mandatory");
*/
        if (ValidationUtils.isBlank(modelToValidate.getExtentType()))
			support.addError("Extent Type", "is mandatory");

		if (modelToValidate.getExtentNumber() == null ||
				modelToValidate.getExtentNumber() == 0)
			support.addError("Extent", "is mandatory");


        checkInclusiveDates(support, modelToValidate);
        checkBulkDates(support, modelToValidate);
        checkInclusiveVsBulkDates(support, modelToValidate);
        
		checkForStringLengths(modelToValidate, support);

		return support.getResult();
	}

}
