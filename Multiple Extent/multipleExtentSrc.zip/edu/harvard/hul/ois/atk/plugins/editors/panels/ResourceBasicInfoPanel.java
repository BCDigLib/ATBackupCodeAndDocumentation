
/**********************************************************************
 * Copyright (c) 2001 by the President and Fellows of Harvard College
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 *
 * Contact information
 *
 * Office for Information Systems
 * Harvard University Library
 * Harvard University
 * Cambridge, MA  02138
 * (617)495-3724
 * hulois@hulmail.harvard.edu
 *
 * This package is based heavily on BYU multiple-extent plugin package for ATK, customized for Harvard University
 *
 */

package edu.harvard.hul.ois.atk.plugins.editors.panels;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.Collections;
import javax.swing.*;
import javax.swing.border.*;
import com.jgoodies.forms.factories.*;
import com.jgoodies.forms.layout.*;
import com.jgoodies.binding.PresentationModel;

import org.archiviststoolkit.mydomain.*;
import org.archiviststoolkit.swing.*;
import org.archiviststoolkit.model.ArchDescription;
import org.archiviststoolkit.model.*;
import org.archiviststoolkit.model.Resources;
import org.archiviststoolkit.util.InLineTagsUtils;
import org.archiviststoolkit.util.LookupListUtils;
import org.archiviststoolkit.structure.ATFieldInfo;
import org.archiviststoolkit.dialog.ErrorDialog;
import org.archiviststoolkit.dialog.DigitalObjectLookup;
import org.archiviststoolkit.exceptions.ObjectNotRemovedException;
import org.archiviststoolkit.exceptions.DomainEditorCreationException;
import org.archiviststoolkit.ApplicationFrame;
import org.archiviststoolkit.editor.ArchDescriptionInstancesEditor;
import edu.harvard.hul.ois.atk.plugins.editors.ArchDescPhysicalDescFields;

import edu.byu.plugins.editors.ArchDescriptionDatesFields;

public class ResourceBasicInfoPanel extends Harvard_DomainEditorFields {

	private Resources resourceModel;
	protected ArchDescriptionInstances currentInstance;
	protected ArchDescriptionInstancesEditor dialogInstances;
	protected String defaultInstanceType = "";


	public ResourceBasicInfoPanel(PresentationModel detailsModel) {
		this.detailsModel = detailsModel;
		initComponents();
        initAccess();
		accessionsTable.setClazzAndColumns(AccessionsResources.PROPERTYNAME_ACCESSION_NUMBER,
				AccessionsResources.class,
				AccessionsResources.PROPERTYNAME_ACCESSION_NUMBER,
				AccessionsResources.PROPERTYNAME_ACCESSION_TITLE);
	}

	public Component getInitialFocusComponent() {
		return resourcesLevel;
	}

	private void resourcesLevelActionPerformed() {
		setOtherLevelEnabledDisabled(resourcesLevel, label_otherLevel, resourcesOtherLevel);
	}

	private void insertInlineTagActionPerformed() {
		InLineTagsUtils.wrapInTagActionPerformed(insertInlineTag, resourcesTitle, editorField.getParentEditor());
	}

	private void dateTableMouseClicked(MouseEvent e) {
		if (e.getClickCount() == 2) {
			try {
				DomainEditor domainEditor = new DomainEditor(ArchDescriptionDates.class, editorField.getParentEditor(), "Dates", new ArchDescriptionDatesFields());
				domainEditor.setCallingTable(dateTable);
				domainEditor.setNavigationButtonListeners(domainEditor);
				editRelatedRecord(dateTable, ArchDescriptionDates.class, true, domainEditor);
			} catch (UnsupportedTableModelException e1) {
				new ErrorDialog("Error creating editor for Dates", e1).showDialog();
			}
		}
	}

	private void addDateActionPerformed(ActionEvent e) {
		System.out.println("Resource add date: " + this.resourceModel);
		addDateActionPerformed(dateTable, resourceModel);
	}

	private void removeDateActionPerformed(ActionEvent e) {
		try {
			this.removeRelatedTableRow(dateTable, resourceModel);
		} catch (ObjectNotRemovedException e1) {
			new ErrorDialog("Date not removed", e1).showDialog();
		}
	}


    private void dateEndFocusGained() {
		Accessions accession = (Accessions) super.getModel();
		if (accession.getDateEnd() == null) {
			accession.setDateEnd((Integer) date1Begin.getValue());
			/* After a formatted text field gains focus, it replaces its text with its
			 * current value, formatted appropriately of course. It does this _after_
			 * any focus listeners are notified. So, if we are editable, we queue
			 * up a selectAll to be done after the current events in the thread are done. */
			Runnable doSelect = new Runnable() {
				public void run() {
					date1End.selectAll();
				}
			};
			SwingUtilities.invokeLater(doSelect);
		}
	}

	private void bulkDateEndFocusGained() {
		Accessions accession = (Accessions) super.getModel();
		if (accession.getBulkDateEnd() == null) {
			accession.setBulkDateEnd((Integer) bulkDateBegin.getValue());
			Runnable doSelect = new Runnable() {
				public void run() {
					bulkDateEnd.selectAll();
				}
			};
			SwingUtilities.invokeLater(doSelect);
		}
	}    

	private void changeRepositoryButtonActionPerformed() {
		Vector repositories = Repositories.getRepositoryList();
		ImageIcon icon = null;
		Repositories currentRepostory = ((Resources) editorField.getModel()).getRepository();
		Resources model = (Resources) editorField.getModel();
        SelectFromList dialog = new SelectFromList(this.getParentEditor(), "Select a repository", repositories.toArray());
        dialog.setSelectedValue(currentRepostory);
        if (dialog.showDialog() == JOptionPane.OK_OPTION) {
            resourceModel.setRepository((Repositories)dialog.getSelectedValue());
            setRepositoryText(resourceModel);
            ApplicationFrame.getInstance().setRecordDirty(); // set the record dirty
        }
	}

	private void setRepositoryText(Resources model) {
		if (model.getRepository() == null) {
			this.repositoryName.setText("");
		} else {
			this.repositoryName.setText(model.getRepository().getShortName());
		}
	}

	public DomainSortableTable getDateTable() {
		return dateTable;
	}

	public JButton getChangeRepositoryButton() {
		return changeRepositoryButton;
	}

	private void physicalDescriptionMouseClicked(MouseEvent e) {
		if (e.getClickCount() == 2) {
			try {
				DomainEditor domainEditor = new DomainEditor(ArchDescriptionPhysicalDescriptions.class, editorField.getParentEditor(), "Physical Descriptions", new ArchDescPhysicalDescFields());
				domainEditor.setCallingTable(physicalDescriptionsTable);
				domainEditor.setNavigationButtonListeners(domainEditor);
				editRelatedRecord(physicalDescriptionsTable, ArchDescriptionPhysicalDescriptions.class, true, domainEditor);
			} catch (UnsupportedTableModelException e1) {
				new ErrorDialog("Error creating editor for Dates", e1).showDialog();
			}
		}
	}

	private void addPhysicalDescriptionActionPerformed() {
		addPhysicalDescriptionActionPerformed(physicalDescriptionsTable, resourceModel);
	}

	private void removePhysicalDescriptionActionPerformed() {
		try {
			this.removeRelatedTableRow(physicalDescriptionsTable, resourceModel);
		} catch (ObjectNotRemovedException e1) {
			new ErrorDialog("Physical description not removed", e1).showDialog();
		}
	}

	private void instancesTableMouseClicked(MouseEvent e) {
		if (e.getClickCount() == 2) {
            // get the current instance record to edit
            DomainObject instanceRecord = null;
            int selectedRow = getInstancesTable().getSelectedRow();
		    if (selectedRow != -1) {
			    instanceRecord = getInstancesTable().getSortedList().get(selectedRow);
            }

            if(usePluginDomainEditor(false, instanceRecord, getInstancesTable())) {
                return;
            }

			if (handleTableMouseClick(e, getInstancesTable(), ArchDescriptionInstances.class) == JOptionPane.OK_OPTION) {
				findLocationForInstance(currentInstance);
			}
		}
	}

	public void findLocationForInstance(ArchDescriptionInstances newInstance) {
		if (newInstance instanceof ArchDescriptionAnalogInstances) {
			final Resources parentResource = (Resources) editorField.getModel();
			final ArchDescriptionAnalogInstances analogInstance = (ArchDescriptionAnalogInstances) newInstance;
			Thread performer = new Thread(new Runnable() {
				public void run() {
					InfiniteProgressPanel monitor = ATProgressUtil.createModalProgressMonitor(ApplicationFrame.getInstance(), 1000);
					monitor.start("Gathering Containers...");
					try {
						analogInstance.setLocation(parentResource.findLocationForContainer(analogInstance.getTopLevelLabel(), monitor));
					} finally {
						monitor.close();
					}
				}
			}, "Performer");
			performer.start();
		}
	}

	private void addInstanceButtonActionPerformed() {
//		ArchDescription archDescriptionModel = (ArchDescription) super.getModel();
		ArchDescriptionInstances newInstance = null;
		Vector<String> possibilities = LookupListUtils.getLookupListValues(LookupListUtils.LIST_NAME_INSTANCE_TYPES);
		ImageIcon icon = null;
		try {
			// add a special entry for digital object link to the possibilities vector
            possibilities.add(ArchDescriptionInstances.DIGITAL_OBJECT_INSTANCE_LINK);
            Collections.sort(possibilities);

            dialogInstances = (ArchDescriptionInstancesEditor) DomainEditorFactory.getInstance().createDomainEditorWithParent(ArchDescriptionInstances.class, getParentEditor(), getInstancesTable());
		} catch (DomainEditorCreationException e) {
			new ErrorDialog(getParentEditor(), "Error creating editor for ArchDescriptionInstances", e).showDialog();
		}

        dialogInstances.setNewRecord(true);

		int returnStatus;
		Boolean done = false;
		while (!done) {
			defaultInstanceType = (String) JOptionPane.showInputDialog(getParentEditor(), "What type of instance would you like to create",
					"", JOptionPane.PLAIN_MESSAGE, icon, possibilities.toArray(), defaultInstanceType);

			if ((defaultInstanceType != null) && (defaultInstanceType.length() > 0)) {
				if (defaultInstanceType.equalsIgnoreCase(ArchDescriptionInstances.DIGITAL_OBJECT_INSTANCE)) {
					newInstance = new ArchDescriptionDigitalInstances(resourceModel,
                            (Resources) editorField.getModel());
					addDatesToNewDigitalInstance((ArchDescriptionDigitalInstances)newInstance, resourceModel);
				} else if (defaultInstanceType.equalsIgnoreCase(ArchDescriptionInstances.DIGITAL_OBJECT_INSTANCE_LINK)) {
                    // add a digital object link or links instead
                    addDigitalInstanceLink((Resources) editorField.getModel());
                    return;
				} else {
					newInstance = new ArchDescriptionAnalogInstances(resourceModel);
				}

                newInstance.setInstanceType(defaultInstanceType);

                // see whether to use a plugin
                if(usePluginDomainEditor(true, newInstance, getInstancesTable())) {
                    return;
                }

				dialogInstances.setModel(newInstance, null);
				dialogInstances.setResourceInfo((Resources) editorField.getModel());
				returnStatus = dialogInstances.showDialog();
				if (returnStatus == JOptionPane.OK_OPTION) {
					dialogInstances.commitChangesToCurrentRecord();
					resourceModel.addInstance(newInstance);
					getInstancesTable().getEventList().add(newInstance);
					findLocationForInstance(newInstance);
                    ApplicationFrame.getInstance().setRecordDirty(); // set the record dirty
					done = true;
				} else if (returnStatus == StandardEditor.OK_AND_ANOTHER_OPTION) {
					dialogInstances.commitChangesToCurrentRecord();
					resourceModel.addInstance(newInstance);
					getInstancesTable().getEventList().add(newInstance);
					findLocationForInstance(newInstance);
                    ApplicationFrame.getInstance().setRecordDirty(); // set the record dirty
				} else {
					done = true;
				}
			} else {
				done = true;
			}
		}
		dialogInstances.setNewRecord(false);
	}

	/**
	 * Method to open dialog that allows linking of digital objects to this resource
	 * or resource component
	 * @param parentResource The parent resource component
	 */
	private void addDigitalInstanceLink(Resources parentResource) {
		DigitalObjectLookup digitalObjectPicker = new DigitalObjectLookup(getParentEditor(), editorField);
		digitalObjectPicker.setParentResource(parentResource);
		digitalObjectPicker.showDialog(this);
	}

	private void removeInstanceButtonActionPerformed() {
		ArchDescription archDescriptionModel = (ArchDescription) super.getModel();
		try {
//			this.removeRelatedTableRow(physicalDescriptionsTable, resourceModel);
			this.removeRelatedTableRow(getInstancesTable(), resourceModel);
		} catch (ObjectNotRemovedException e) {
			new ErrorDialog("Instance not removed", e).showDialog();
		}
	}

	public DomainSortableTable getPhysicalDescriptionsTable() {
		return physicalDescriptionsTable;
	}

	public DomainSortableTable getInstancesTable() {
		return instancesTable;
	}

	public JButton getAddInstanceButton() {
		return addInstanceButton;
	}

	public JButton getRemoveInstanceButton() {
		return removeInstanceButton;
	}

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner non-commercial license
		panel16 = new JPanel();
		panel19 = new JPanel();
		label_resourcesLevel = new JLabel();
		resourcesLevel = ATBasicComponentFactory.createComboBox(detailsModel, Resources.PROPERTYNAME_LEVEL, Resources.class);
		label_otherLevel = new JLabel();
		resourcesOtherLevel = ATBasicComponentFactory.createTextField(detailsModel.getModel(Resources.PROPERTYNAME_OTHER_LEVEL),false);
		label_resourcesTitle = new JLabel();
		scrollPane2 = new JScrollPane();
		resourcesTitle = ATBasicComponentFactory.createTextArea(detailsModel.getModel(ArchDescription.PROPERTYNAME_TITLE),false);
		tagApplicatorPanel = new JPanel();
		insertInlineTag = ATBasicComponentFactory.createUnboundComboBox(InLineTagsUtils.getInLineTagList(InLineTagsUtils.TITLE));
		label_repositoryName4 = new JLabel();
		scrollPane8 = new JScrollPane();
		dateTable = new DomainSortableTable(ArchDescriptionDates.class);
		panel22 = new JPanel();
		addDate = new JButton();
		removeDate = new JButton();
		panel1 = new JPanel();
		label_resourcesLanguageCode = new JLabel();
		resourcesLanguageCode = ATBasicComponentFactory.createComboBox(detailsModel, Resources.PROPERTYNAME_LANGUAGE_CODE, Resources.class);
		label_resourcesLanguageNote = new JLabel();
		scrollPane423 = new JScrollPane();
		resourcesLanguageNote = ATBasicComponentFactory.createTextArea(detailsModel.getModel(Resources.PROPERTYNAME_REPOSITORY_PROCESSING_NOTE),false);
		panel6 = new JPanel();
		label_agreementReceived2 = new JLabel();
		repositoryName = new JTextField();
		changeRepositoryButton = new JButton();
		separator2 = new JSeparator();
		panel13 = new JPanel();
		panel17 = new JPanel();
		panel12 = new JPanel();
		label_resourceIdentifier1 = new JLabel();
		resourceIdentifier1 = ATBasicComponentFactory.createTextField(detailsModel.getModel(Resources.PROPERTYNAME_RESOURCE_IDENTIFIER_1));
		resourceIdentifier2 = ATBasicComponentFactory.createTextField(detailsModel.getModel(Resources.PROPERTYNAME_RESOURCE_IDENTIFIER_2));
		resourceIdentifier3 = ATBasicComponentFactory.createTextField(detailsModel.getModel(Resources.PROPERTYNAME_RESOURCE_IDENTIFIER_3));
		resourceIdentifier4 = ATBasicComponentFactory.createTextField(detailsModel.getModel(Resources.PROPERTYNAME_RESOURCE_IDENTIFIER_4));
		panel42 = new JPanel();
		panel43 = new JPanel();
		OtherAccessionsLabel = new JLabel();
		scrollPane4 = new JScrollPane();
		accessionsTable = new DomainSortableTable();
		label_repositoryName5 = new JLabel();
		scrollPane9 = new JScrollPane();
		physicalDescriptionsTable = new DomainSortableTable(ArchDescriptionPhysicalDescriptions.class);
		panel23 = new JPanel();
		addPhysicalDescription = new JButton();
		removePhysicalDescription = new JButton();
		panel39 = new JPanel();
		panel40 = new JPanel();
		label1 = new JLabel();
		scrollPane6 = new JScrollPane();
		instancesTable = new DomainSortableTable(ArchDescriptionInstances.class, ArchDescriptionInstances.PROPERTYNAME_INSTANCE_TYPE);
		panel29 = new JPanel();
		addInstanceButton = new JButton();
		removeInstanceButton = new JButton();
		panel2 = new JPanel();
		restrictionsApply2 = ATBasicComponentFactory.createCheckBox(detailsModel, Resources.PROPERTYNAME_INTERNAL_ONLY, Resources.class);
		restrictionsApply = ATBasicComponentFactory.createCheckBox(detailsModel, ArchDescription.PROPERTYNAME_RESTRICTIONS_APPLY, Resources.class);
		CellConstraints cc = new CellConstraints();

        panel20 = new JPanel();
        panel21 = new JPanel();
        //scrollPane423 = new JScrollPane();
        ExtentNumberLabel2 = new JLabel();
        labelExtentNumber = new JLabel();
        extentNumber = ATBasicComponentFactory.createDoubleField(detailsModel,Accessions.PROPERTYNAME_EXTENT_NUMBER);
        extentType = ATBasicComponentFactory.createComboBox(detailsModel, Accessions.PROPERTYNAME_EXTENT_TYPE, Accessions.class);
        labelExtent = new JLabel();
        containerSummary = ATBasicComponentFactory.createTextArea(detailsModel.getModel(Accessions.PROPERTYNAME_CONTAINER_SUMMARY),false);
        panelPhysDescr = new JPanel();

        //put back original date panel (not multiple dates)
        panel5 = new JPanel();
        panel4 = new JPanel();
        label_dateExpression = new JLabel();
        dateExpression = ATBasicComponentFactory.createTextField(detailsModel.getModel(ArchDescription.PROPERTYNAME_DATE_EXPRESSION),false);
        Date1Label = new JLabel();
        label_date1Begin = new JLabel();
        date1Begin = ATBasicComponentFactory.createIntegerField(detailsModel,ArchDescription.PROPERTYNAME_DATE_BEGIN);
        label_date1End = new JLabel();
        date1End = ATBasicComponentFactory.createIntegerField(detailsModel,ArchDescription.PROPERTYNAME_DATE_END);
        BulkDatesLabel = new JLabel();
        label_bulkDateBegin = new JLabel();
        bulkDateBegin = ATBasicComponentFactory.createIntegerField(detailsModel,Accessions.PROPERTYNAME_BULK_DATE_BEGIN);
        label_bulkDateEnd = new JLabel();
        bulkDateEnd = ATBasicComponentFactory.createIntegerField(detailsModel,Accessions.PROPERTYNAME_BULK_DATE_END);

        tabbedPane9 = new JTabbedPane();

		//======== this ========
		setBackground(new Color(200, 205, 232));
		setLayout(new FormLayout(
			new ColumnSpec[] {
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC
			},
			RowSpec.decodeSpecs("default")));

		//======== panel16 ========
		{
			panel16.setOpaque(false);
			panel16.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
			panel16.setBorder(Borders.DLU2_BORDER);
			panel16.setLayout(new FormLayout(
				ColumnSpec.decodeSpecs("default:grow"),
				new RowSpec[] {
					new RowSpec(RowSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
					FormFactory.LINE_GAP_ROWSPEC,
					FormFactory.DEFAULT_ROWSPEC,
					FormFactory.LINE_GAP_ROWSPEC,
					FormFactory.DEFAULT_ROWSPEC,
					FormFactory.LINE_GAP_ROWSPEC,
					new RowSpec(RowSpec.TOP, Sizes.DEFAULT, FormSpec.NO_GROW),
					FormFactory.LINE_GAP_ROWSPEC,
					FormFactory.DEFAULT_ROWSPEC,
					FormFactory.LINE_GAP_ROWSPEC,
					new RowSpec(RowSpec.TOP, Sizes.DEFAULT, FormSpec.NO_GROW),
					FormFactory.LINE_GAP_ROWSPEC,
					new RowSpec(RowSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
					FormFactory.LINE_GAP_ROWSPEC,
					FormFactory.DEFAULT_ROWSPEC
				}));

			//======== panel19 ========
			{
				panel19.setOpaque(false);
				panel19.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				panel19.setLayout(new FormLayout(
					new ColumnSpec[] {
						FormFactory.DEFAULT_COLSPEC,
						FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
						new ColumnSpec(ColumnSpec.LEFT, Sizes.DEFAULT, FormSpec.DEFAULT_GROW)
					},
					new RowSpec[] {
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.LINE_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.LINE_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.LINE_GAP_ROWSPEC,
						new RowSpec(RowSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
						FormFactory.LINE_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC
					}));

				//---- label_resourcesLevel ----
				label_resourcesLevel.setText("Level");
				label_resourcesLevel.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				ATFieldInfo.assignLabelInfo(label_resourcesLevel, Resources.class, Resources.PROPERTYNAME_LEVEL);
				panel19.add(label_resourcesLevel, cc.xywh(1, 1, 1, 1, CellConstraints.FILL, CellConstraints.DEFAULT));

				//---- resourcesLevel ----
				resourcesLevel.setOpaque(false);
				resourcesLevel.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				resourcesLevel.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						resourcesLevelActionPerformed();
					}
				});
				panel19.add(resourcesLevel, cc.xywh(3, 1, 1, 1, CellConstraints.LEFT, CellConstraints.DEFAULT));

				//---- label_otherLevel ----
				label_otherLevel.setText("Other Level");
				label_otherLevel.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				ATFieldInfo.assignLabelInfo(label_otherLevel, Resources.class, Resources.PROPERTYNAME_OTHER_LEVEL);
				panel19.add(label_otherLevel, cc.xy(1, 3));

				//---- resourcesOtherLevel ----
				resourcesOtherLevel.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				panel19.add(resourcesOtherLevel, new CellConstraints(3, 3, 1, 1, CellConstraints.FILL, CellConstraints.TOP, new Insets( 0, 0, 0, 5)));

				//---- label_resourcesTitle ----
				label_resourcesTitle.setText("Title");
				label_resourcesTitle.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				ATFieldInfo.assignLabelInfo(label_resourcesTitle, Resources.class, Resources.PROPERTYNAME_TITLE);
				panel19.add(label_resourcesTitle, cc.xywh(1, 5, 3, 1));

				//======== scrollPane2 ========
				{

					//---- resourcesTitle ----
					resourcesTitle.setRows(4);
					resourcesTitle.setLineWrap(true);
					resourcesTitle.setWrapStyleWord(true);
					resourcesTitle.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					scrollPane2.setViewportView(resourcesTitle);
				}
				panel19.add(scrollPane2, cc.xywh(1, 7, 3, 1));

				//======== tagApplicatorPanel ========
				{
					tagApplicatorPanel.setOpaque(false);
					tagApplicatorPanel.setLayout(new FormLayout(
						new ColumnSpec[] {
							FormFactory.DEFAULT_COLSPEC,
							FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
							FormFactory.DEFAULT_COLSPEC,
							FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
							FormFactory.DEFAULT_COLSPEC
						},
						RowSpec.decodeSpecs("default")));

					//---- insertInlineTag ----
					insertInlineTag.setOpaque(false);
					insertInlineTag.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					insertInlineTag.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							insertInlineTagActionPerformed();
						}
					});
					tagApplicatorPanel.add(insertInlineTag, cc.xy(1, 1));
				}
				panel19.add(tagApplicatorPanel, cc.xywh(1, 9, 3, 1));
			}
			panel16.add(panel19, cc.xy(1, 1));

			//---- label_repositoryName4 ----
            /*
			label_repositoryName4.setText("Dates");
			label_repositoryName4.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
			panel16.add(label_repositoryName4, cc.xy(1, 3));
			*/

			//======== scrollPane8 ========
			/*
            {
				scrollPane8.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
				scrollPane8.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				scrollPane8.setPreferredSize(new Dimension(200, 104));

				//---- dateTable ----
				dateTable.setPreferredScrollableViewportSize(new Dimension(200, 100));
				dateTable.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						dateTableMouseClicked(e);
					}
				});
				scrollPane8.setViewportView(dateTable);
			}
			panel16.add(scrollPane8, cc.xywh(1, 5, 1, 1, CellConstraints.DEFAULT, CellConstraints.FILL));
            */
			//======== panel22 ========
                    {
                        panel22.setBorder(new BevelBorder(BevelBorder.LOWERED));
                        panel22.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                        panel22.setBackground(new Color(182, 187, 212));
                        panel22.setLayout(new FormLayout(
                            ColumnSpec.decodeSpecs("default:grow"),
                            new RowSpec[] {
                                new RowSpec(RowSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
                                FormFactory.RELATED_GAP_ROWSPEC
                            }));

                        //======== panel5 ========
                        {
                            panel5.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                            panel5.setOpaque(false);
                            panel5.setBorder(Borders.DLU2_BORDER);
                            panel5.setLayout(new FormLayout(
                                new ColumnSpec[] {
                                    new ColumnSpec("max(min;50px)"),
                                    FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
                                    FormFactory.DEFAULT_COLSPEC,
                                    FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
                                    new ColumnSpec(ColumnSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
                                    FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
                                    FormFactory.DEFAULT_COLSPEC,
                                    FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
                                    new ColumnSpec(ColumnSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW)
                                },
                                new RowSpec[] {
                                    FormFactory.DEFAULT_ROWSPEC,
                                    FormFactory.LINE_GAP_ROWSPEC,
                                    FormFactory.DEFAULT_ROWSPEC,
                                    FormFactory.LINE_GAP_ROWSPEC,
                                    FormFactory.DEFAULT_ROWSPEC,
                                    FormFactory.LINE_GAP_ROWSPEC,
                                    FormFactory.DEFAULT_ROWSPEC,
                                    FormFactory.LINE_GAP_ROWSPEC,
                                    FormFactory.DEFAULT_ROWSPEC
                                }));

                            //======== panel4 ========
                            {
                                panel4.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                                panel4.setOpaque(false);
                                panel4.setLayout(new FormLayout(
                                    new ColumnSpec[] {
                                        new ColumnSpec(ColumnSpec.LEFT, Sizes.PREFERRED, FormSpec.NO_GROW),
                                        FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
                                        new ColumnSpec(ColumnSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW)
                                    },
                                    RowSpec.decodeSpecs("default:grow")));

                                //---- label_dateExpression ----
                                label_dateExpression.setText("Date Expression");
                                label_dateExpression.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                                ATFieldInfo.assignLabelInfo(label_dateExpression, Accessions.class, Accessions.PROPERTYNAME_DATE_EXPRESSION);
                                panel4.add(label_dateExpression, cc.xywh(1, 1, 1, 1, CellConstraints.LEFT, CellConstraints.DEFAULT));

                                //---- dateExpression ----
                                dateExpression.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                                panel4.add(dateExpression, new CellConstraints(3, 1, 1, 1, CellConstraints.DEFAULT, CellConstraints.DEFAULT, new Insets( 0, 0, 0, 5)));
                            }
                            panel5.add(panel4, cc.xywh(1, 1, 9, 1));

                            //---- Date1Label ----
                            Date1Label.setText("Date");
                            Date1Label.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                            panel5.add(Date1Label, cc.xywh(1, 3, 9, 1));

                            //---- label_date1Begin ----
                            label_date1Begin.setText("Begin");
                            label_date1Begin.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                            ATFieldInfo.assignLabelInfo(label_date1Begin, Accessions.class, Accessions.PROPERTYNAME_DATE_BEGIN);
                            panel5.add(label_date1Begin, cc.xy(3, 5));

                            //---- date1Begin ----
                            date1Begin.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                            panel5.add(date1Begin, cc.xywh(5, 5, 1, 1, CellConstraints.FILL, CellConstraints.DEFAULT));

                            //---- label_date1End ----
                            label_date1End.setText("End");
                            label_date1End.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                            ATFieldInfo.assignLabelInfo(label_date1End, Accessions.class, Accessions.PROPERTYNAME_DATE_END);
                            panel5.add(label_date1End, cc.xy(7, 5));

                            //---- date1End ----
                            date1End.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                            date1End.addFocusListener(new FocusAdapter() {
                                @Override
                                public void focusGained(FocusEvent e) {
                                    dateEndFocusGained();
                                }
                            });
                            panel5.add(date1End, new CellConstraints(9, 5, 1, 1, CellConstraints.FILL, CellConstraints.DEFAULT, new Insets( 0, 0, 0, 5)));

                            //---- BulkDatesLabel ----
                            BulkDatesLabel.setText("Bulk Dates");
                            BulkDatesLabel.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                            panel5.add(BulkDatesLabel, cc.xywh(1, 7, 9, 1));

                            //---- label_bulkDateBegin ----
                            label_bulkDateBegin.setText("Begin");
                            label_bulkDateBegin.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                            ATFieldInfo.assignLabelInfo(label_bulkDateBegin, Accessions.class, Accessions.PROPERTYNAME_BULK_DATE_BEGIN);
                            panel5.add(label_bulkDateBegin, cc.xy(3, 9));

                            //---- bulkDateBegin ----
                            bulkDateBegin.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                            panel5.add(bulkDateBegin, cc.xywh(5, 9, 1, 1, CellConstraints.FILL, CellConstraints.DEFAULT));

                            //---- label_bulkDateEnd ----
                            label_bulkDateEnd.setText("End");
                            label_bulkDateEnd.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                            ATFieldInfo.assignLabelInfo(label_bulkDateEnd, Accessions.class, Accessions.PROPERTYNAME_BULK_DATE_END);
                            panel5.add(label_bulkDateEnd, cc.xy(7, 9));

                            //---- bulkDateEnd ----
                            bulkDateEnd.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                            bulkDateEnd.addFocusListener(new FocusAdapter() {
                                @Override
                                public void focusGained(FocusEvent e) {
                                    bulkDateEndFocusGained();
                                }
                            });
                            panel5.add(bulkDateEnd, new CellConstraints(9, 9, 1, 1, CellConstraints.FILL, CellConstraints.DEFAULT, new Insets( 0, 0, 0, 5)));
                        }
                        panel22.add(panel5, cc.xy(1, 1));
                    }
			//panel16.add(panel22, cc.xywh(1, 7, 1, 1, CellConstraints.CENTER, CellConstraints.DEFAULT));
            panel16.add(panel22, cc.xy(1,7));
			//======== panel1 ========
			{
				panel1.setOpaque(false);
				panel1.setLayout(new FormLayout(
					new ColumnSpec[] {
						new ColumnSpec(ColumnSpec.LEFT, Sizes.DEFAULT, FormSpec.NO_GROW),
						FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
						new ColumnSpec("left:min(default;200px)")
					},
					RowSpec.decodeSpecs("default")));

				//---- label_resourcesLanguageCode ----
				label_resourcesLanguageCode.setText("Language");
				label_resourcesLanguageCode.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				ATFieldInfo.assignLabelInfo(label_resourcesLanguageCode, Resources.class, Resources.PROPERTYNAME_LANGUAGE_CODE);
				panel1.add(label_resourcesLanguageCode, cc.xy(1, 1));

				//---- resourcesLanguageCode ----
				resourcesLanguageCode.setMaximumSize(new Dimension(50, 27));
				resourcesLanguageCode.setOpaque(false);
				resourcesLanguageCode.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				panel1.add(resourcesLanguageCode, cc.xywh(3, 1, 1, 1, CellConstraints.LEFT, CellConstraints.DEFAULT));
			}
			panel16.add(panel1, cc.xy(1, 9));

			//---- label_resourcesLanguageNote ----
			label_resourcesLanguageNote.setText("Repository Processing Note");
			label_resourcesLanguageNote.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
			ATFieldInfo.assignLabelInfo(label_resourcesLanguageNote, Resources.class, Resources.PROPERTYNAME_REPOSITORY_PROCESSING_NOTE);
			panel16.add(label_resourcesLanguageNote, cc.xy(1, 11));

			//======== scrollPane423 ========
			{
				scrollPane423.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
				scrollPane423.setOpaque(false);
				scrollPane423.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));

				//---- resourcesLanguageNote ----
				resourcesLanguageNote.setRows(4);
				resourcesLanguageNote.setLineWrap(true);
				resourcesLanguageNote.setWrapStyleWord(true);
				resourcesLanguageNote.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				scrollPane423.setViewportView(resourcesLanguageNote);
			}
			panel16.add(scrollPane423, cc.xy(1, 13));

			//======== panel6 ========
			{
				panel6.setOpaque(false);
				panel6.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				panel6.setLayout(new FormLayout(
					new ColumnSpec[] {
						FormFactory.DEFAULT_COLSPEC,
						FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
						new ColumnSpec(ColumnSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW)
					},
					new RowSpec[] {
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.LINE_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC
					}));

				//---- label_agreementReceived2 ----
				label_agreementReceived2.setText("Repository");
				label_agreementReceived2.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				ATFieldInfo.assignLabelInfo(label_agreementReceived2, Resources.class, Resources.PROPERTYNAME_REPOSITORY);
				panel6.add(label_agreementReceived2, cc.xy(1, 1));

				//---- repositoryName ----
				repositoryName.setEditable(false);
				repositoryName.setOpaque(false);
				repositoryName.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				repositoryName.setBorder(null);
				panel6.add(repositoryName, cc.xy(3, 1));

				//---- changeRepositoryButton ----
				changeRepositoryButton.setText("Change Repository");
				changeRepositoryButton.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				changeRepositoryButton.setOpaque(false);
				changeRepositoryButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						changeRepositoryButtonActionPerformed();
					}
				});
				panel6.add(changeRepositoryButton, cc.xywh(3, 3, 1, 1, CellConstraints.CENTER, CellConstraints.DEFAULT));
			}
			panel16.add(panel6, cc.xy(1, 15));
		}
		add(panel16, cc.xywh(1, 1, 1, 1, CellConstraints.FILL, CellConstraints.DEFAULT));

		//---- separator2 ----
		separator2.setForeground(new Color(147, 131, 86));
		separator2.setOrientation(SwingConstants.VERTICAL);
		add(separator2, cc.xywh(3, 1, 1, 1, CellConstraints.FILL, CellConstraints.FILL));

		//======== panel13 ========
		{
			panel13.setOpaque(false);
			panel13.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
			panel13.setBorder(Borders.DLU2_BORDER);
			panel13.setLayout(new FormLayout(
				"default:grow",
				"fill:default:grow"));

			//======== panel17 ========
			{
				panel17.setOpaque(false);
				panel17.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				panel17.setLayout(new FormLayout(
					ColumnSpec.decodeSpecs("default:grow"),
					new RowSpec[] {
						new RowSpec(RowSpec.TOP, Sizes.DEFAULT, FormSpec.NO_GROW),
						FormFactory.LINE_GAP_ROWSPEC,
						new RowSpec(RowSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
						FormFactory.LINE_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.LINE_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.LINE_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.LINE_GAP_ROWSPEC,
						new RowSpec(RowSpec.CENTER, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
						FormFactory.LINE_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC
					}));

				//======== panel12 ========
				{
					panel12.setBackground(new Color(231, 188, 251));
					panel12.setOpaque(false);
					panel12.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					panel12.setLayout(new FormLayout(
						new ColumnSpec[] {
							FormFactory.DEFAULT_COLSPEC,
							FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
							new ColumnSpec(ColumnSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
							FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
							new ColumnSpec(ColumnSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
							FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
							new ColumnSpec(ColumnSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
							FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
							new ColumnSpec(ColumnSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW)
						},
						RowSpec.decodeSpecs("default")));
					((FormLayout)panel12.getLayout()).setColumnGroups(new int[][] {{3, 5, 7, 9}});

					//---- label_resourceIdentifier1 ----
					label_resourceIdentifier1.setText("Resource ID");
					label_resourceIdentifier1.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					ATFieldInfo.assignLabelInfo(label_resourceIdentifier1, Resources.class, Resources.PROPERTYNAME_RESOURCE_IDENTIFIER);
					panel12.add(label_resourceIdentifier1, cc.xy(1, 1));

					//---- resourceIdentifier1 ----
					resourceIdentifier1.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					panel12.add(resourceIdentifier1, cc.xy(3, 1));

					//---- resourceIdentifier2 ----
					resourceIdentifier2.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					panel12.add(resourceIdentifier2, cc.xy(5, 1));

					//---- resourceIdentifier3 ----
					resourceIdentifier3.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					panel12.add(resourceIdentifier3, cc.xy(7, 1));

					//---- resourceIdentifier4 ----
					resourceIdentifier4.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					panel12.add(resourceIdentifier4, cc.xy(9, 1));
				}
				panel17.add(panel12, cc.xy(1, 1));

				//======== panel42 ========
				{
					panel42.setBorder(new BevelBorder(BevelBorder.LOWERED));
					panel42.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					panel42.setBackground(new Color(182, 187, 212));
					panel42.setLayout(new FormLayout(
						ColumnSpec.decodeSpecs("default:grow"),
						new RowSpec[] {
							new RowSpec(RowSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
							FormFactory.RELATED_GAP_ROWSPEC
						}));

					//======== panel43 ========
					{
						panel43.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
						panel43.setOpaque(false);
						panel43.setBorder(Borders.DLU2_BORDER);
						panel43.setLayout(new FormLayout(
							ColumnSpec.decodeSpecs("default:grow"),
							new RowSpec[] {
								FormFactory.DEFAULT_ROWSPEC,
								FormFactory.LINE_GAP_ROWSPEC,
								new RowSpec(RowSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW)
							}));

						//---- OtherAccessionsLabel ----
						OtherAccessionsLabel.setText("Accessions linked to this Resource ID:");
						OtherAccessionsLabel.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
						panel43.add(OtherAccessionsLabel, cc.xy(1, 1));

						//======== scrollPane4 ========
						{
							scrollPane4.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
							scrollPane4.setPreferredSize(new Dimension(300, 100));
							scrollPane4.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));

							//---- accessionsTable ----
							accessionsTable.setPreferredScrollableViewportSize(new Dimension(300, 100));
							accessionsTable.setFocusable(false);
							scrollPane4.setViewportView(accessionsTable);
						}
						panel43.add(scrollPane4, cc.xywh(1, 3, 1, 1, CellConstraints.FILL, CellConstraints.DEFAULT));
					}
					panel42.add(panel43, cc.xy(1, 1));
				}
				panel17.add(panel42, cc.xy(1, 3));

				//---- label_repositoryName5 ----
				label_repositoryName5.setText("Physical Description");
				label_repositoryName5.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				panel17.add(label_repositoryName5, cc.xy(1, 5));
    {            
    tabbedPane9.setFocusable(false);
    tabbedPane9.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
    tabbedPane9.setBackground(new Color(200, 205, 232));
    tabbedPane9.setOpaque(true);
    tabbedPane9.setMinimumSize(new Dimension(200, 110));

				//======== panel15 ========
				{
					panelPhysDescr.setOpaque(false);
					panelPhysDescr.setBorder(Borders.DLU2_BORDER);
					panelPhysDescr.setMinimumSize(new Dimension(200, 88));
					panelPhysDescr.setPreferredSize(new Dimension(200, 115));
					panelPhysDescr.setLayout(new FormLayout(
						ColumnSpec.decodeSpecs("default:grow"),
						new RowSpec[] {
							FormFactory.DEFAULT_ROWSPEC,
							FormFactory.LINE_GAP_ROWSPEC,
							new RowSpec(RowSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
							FormFactory.LINE_GAP_ROWSPEC,
							FormFactory.DEFAULT_ROWSPEC
						}));

			//======== scrollPane9 ========
			{
				scrollPane9.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
				scrollPane9.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				scrollPane9.setPreferredSize(new Dimension(200, 104));

				//---- physicalDescriptionsTable ----
				physicalDescriptionsTable.setPreferredScrollableViewportSize(new Dimension(200, 100));
				physicalDescriptionsTable.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						physicalDescriptionMouseClicked(e);
					}
				});
				scrollPane9.setViewportView(physicalDescriptionsTable);
			}
            panelPhysDescr.add(scrollPane9,cc.xy(1, 1));

    			//======== panel23 ========
			{
				panel23.setBackground(new Color(231, 188, 251));
				panel23.setOpaque(false);
				panel23.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				panel23.setMinimumSize(new Dimension(100, 29));
				panel23.setLayout(new FormLayout(
					new ColumnSpec[] {
						FormFactory.DEFAULT_COLSPEC,
						FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
						FormFactory.DEFAULT_COLSPEC
					},
					RowSpec.decodeSpecs("default")));

				//---- addPhysicalDescription ----
				addPhysicalDescription.setText("Add Description");
				addPhysicalDescription.setOpaque(false);
				addPhysicalDescription.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				addPhysicalDescription.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						addPhysicalDescriptionActionPerformed();
					}
				});
				panel23.add(addPhysicalDescription, cc.xy(1, 1));

				//---- removePhysicalDescription ----
				removePhysicalDescription.setText("Remove Description");
				removePhysicalDescription.setOpaque(false);
				removePhysicalDescription.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
				removePhysicalDescription.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						removePhysicalDescriptionActionPerformed();
					}
				});
				panel23.add(removePhysicalDescription, cc.xy(3, 1));

			}
            panelPhysDescr.add(panel23,cc.xywh(1, 5, 1, 1, CellConstraints.CENTER, CellConstraints.DEFAULT));
     }
/*
				//======== scrollPane9 ========
				{
					scrollPane9.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
					scrollPane9.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					scrollPane9.setPreferredSize(new Dimension(200, 104));

					//---- physicalDescriptionsTable ----
					physicalDescriptionsTable.setPreferredScrollableViewportSize(new Dimension(200, 100));
					physicalDescriptionsTable.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							physicalDescriptionMouseClicked(e);
						}
					});
					scrollPane9.setViewportView(physicalDescriptionsTable);
				}
				panel17.add(scrollPane9, cc.xywh(1, 7, 1, 1, CellConstraints.DEFAULT, CellConstraints.FILL));
 */
                //======== panel20 ========
        {
            panel20.setOpaque(false);
            panel20.setBorder(Borders.DLU2_BORDER);
            panel20.setPreferredSize(new Dimension(200, 148));
            panel20.setLayout(new FormLayout(
                new ColumnSpec[] {
                    FormFactory.UNRELATED_GAP_COLSPEC,
                    new ColumnSpec(ColumnSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW)
                },
                new RowSpec[] {
                    FormFactory.DEFAULT_ROWSPEC,
                    FormFactory.LINE_GAP_ROWSPEC,
                    FormFactory.DEFAULT_ROWSPEC,
                    FormFactory.LINE_GAP_ROWSPEC,
                    FormFactory.DEFAULT_ROWSPEC,
                    FormFactory.LINE_GAP_ROWSPEC,
                    new RowSpec(RowSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW)
                }));

            //---- ExtentNumberLabel2 ----
            ExtentNumberLabel2.setText("Extent");
            ExtentNumberLabel2.setForeground(new Color(0, 0, 102));
            ExtentNumberLabel2.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
            //panel20.add(ExtentNumberLabel2, cc.xywh(1, 1, 2, 1));

            //======== panel21 ========
            {
                panel21.setOpaque(false);
                panel21.setLayout(new FormLayout(
                    new ColumnSpec[] {
                        FormFactory.DEFAULT_COLSPEC,
                        FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
                        FormFactory.DEFAULT_COLSPEC,
                        FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
                        FormFactory.DEFAULT_COLSPEC
                    },
                    RowSpec.decodeSpecs("default")));

                //---- labelExtentNumber ----
                labelExtentNumber.setText("Extent");
                labelExtentNumber.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                ATFieldInfo.assignLabelInfo(labelExtentNumber, Accessions.class, Accessions.PROPERTYNAME_EXTENT_NUMBER);
                panel21.add(labelExtentNumber, cc.xy(1, 1));

                //---- extentNumber ----
                extentNumber.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                extentNumber.setColumns(5);
                panel21.add(extentNumber, cc.xy(3, 1));

                //---- extentType ----
                extentType.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                extentType.setOpaque(false);
                panel21.add(extentType, cc.xy(5, 1));
            }
            panel20.add(panel21, cc.xy(2, 3));

            //---- labelExtent ----
            labelExtent.setText("Container Summary");
            labelExtent.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
            ATFieldInfo.assignLabelInfo(labelExtent, Accessions.class, Accessions.PROPERTYNAME_CONTAINER_SUMMARY);
            panel20.add(labelExtent, cc.xy(2, 5));

            //======== scrollPane423 ========
            {
                scrollPane423.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
                scrollPane423.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                scrollPane423.setPreferredSize(new Dimension(200, 68));

                //---- containerSummary ----
                containerSummary.setRows(4);
                containerSummary.setLineWrap(true);
                containerSummary.setWrapStyleWord(true);
                containerSummary.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
                scrollPane423.setViewportView(containerSummary);
            }
            panel20.add(scrollPane423, cc.xywh(2, 7, 1, 1, CellConstraints.DEFAULT, CellConstraints.FILL));
        }

}
tabbedPane9.addTab("Primary Extent", panel20);
tabbedPane9.addTab("Alternate Extent", panelPhysDescr);
//panel17.add(tabbedPane9, cc.xywh(1, 15, 1, 1, CellConstraints.DEFAULT, CellConstraints.FILL));
panel17.add(tabbedPane9, cc.xywh(1, 11, 1, 1, CellConstraints.DEFAULT, CellConstraints.FILL));

/*
				//======== panel23 ========
				{
					panel23.setBackground(new Color(231, 188, 251));
					panel23.setOpaque(false);
					panel23.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					panel23.setMinimumSize(new Dimension(100, 29));
					panel23.setLayout(new FormLayout(
						new ColumnSpec[] {
							FormFactory.DEFAULT_COLSPEC,
							FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
							FormFactory.DEFAULT_COLSPEC
						},
						RowSpec.decodeSpecs("default")));

					//---- addPhysicalDescription ----
					addPhysicalDescription.setText("Add Description");
					addPhysicalDescription.setOpaque(false);
					addPhysicalDescription.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					addPhysicalDescription.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							addPhysicalDescriptionActionPerformed();
						}
					});
					panel23.add(addPhysicalDescription, cc.xy(1, 1));

					//---- removePhysicalDescription ----
					removePhysicalDescription.setText("Remove Description");
					removePhysicalDescription.setOpaque(false);
					removePhysicalDescription.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					removePhysicalDescription.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							removePhysicalDescriptionActionPerformed();
						}
					});
					panel23.add(removePhysicalDescription, cc.xy(3, 1));
				}
				panel17.add(panel23, cc.xywh(1, 9, 1, 1, CellConstraints.CENTER, CellConstraints.DEFAULT));
*/
				//======== panel39 ========
				{
					panel39.setBorder(new BevelBorder(BevelBorder.LOWERED));
					panel39.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					panel39.setBackground(new Color(182, 187, 212));
					panel39.setLayout(new FormLayout(
						ColumnSpec.decodeSpecs("default:grow"),
						new RowSpec[] {
							new RowSpec(RowSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
							FormFactory.RELATED_GAP_ROWSPEC
						}));

					//======== panel40 ========
					{
						panel40.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
						panel40.setOpaque(false);
						panel40.setBorder(Borders.DLU2_BORDER);
						panel40.setLayout(new FormLayout(
							ColumnSpec.decodeSpecs("default:grow"),
							new RowSpec[] {
								FormFactory.DEFAULT_ROWSPEC,
								FormFactory.LINE_GAP_ROWSPEC,
								new RowSpec(RowSpec.FILL, Sizes.DEFAULT, FormSpec.DEFAULT_GROW),
								FormFactory.LINE_GAP_ROWSPEC,
								FormFactory.DEFAULT_ROWSPEC
							}));

						//---- label1 ----
						label1.setText("Instances");
						label1.setForeground(new Color(0, 0, 102));
						label1.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
						ATFieldInfo.assignLabelInfo(label1, Resources.class, ResourcesComponents.PROPERTYNAME_INSTANCES);
						panel40.add(label1, cc.xy(1, 1));

						//======== scrollPane6 ========
						{
							scrollPane6.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
							scrollPane6.setOpaque(false);
							scrollPane6.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));

							//---- instancesTable ----
							instancesTable.setPreferredScrollableViewportSize(new Dimension(200, 75));
							instancesTable.setRowHeight(20);
							instancesTable.setFocusable(false);
							instancesTable.addMouseListener(new MouseAdapter() {
								@Override
								public void mouseClicked(MouseEvent e) {
									instancesTableMouseClicked(e);
								}
							});
							scrollPane6.setViewportView(instancesTable);
						}
						panel40.add(scrollPane6, cc.xywh(1, 3, 1, 1, CellConstraints.DEFAULT, CellConstraints.FILL));

						//======== panel29 ========
						{
							panel29.setBackground(new Color(231, 188, 251));
							panel29.setOpaque(false);
							panel29.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
							panel29.setLayout(new FormLayout(
								new ColumnSpec[] {
									FormFactory.DEFAULT_COLSPEC,
									FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
									FormFactory.DEFAULT_COLSPEC
								},
								RowSpec.decodeSpecs("default")));

							//---- addInstanceButton ----
							addInstanceButton.setText("Add Instance");
							addInstanceButton.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
							addInstanceButton.setOpaque(false);
							addInstanceButton.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									addInstanceButtonActionPerformed();
								}
							});
							panel29.add(addInstanceButton, cc.xy(1, 1));

							//---- removeInstanceButton ----
							removeInstanceButton.setText("Remove Instance");
							removeInstanceButton.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
							removeInstanceButton.setOpaque(false);
							removeInstanceButton.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									removeInstanceButtonActionPerformed();
								}
							});
							panel29.add(removeInstanceButton, cc.xy(3, 1));
						}
						panel40.add(panel29, cc.xywh(1, 5, 1, 1, CellConstraints.CENTER, CellConstraints.DEFAULT));
					}
					panel39.add(panel40, cc.xy(1, 1));
				}
				panel17.add(panel39, cc.xywh(1, 13, 1, 1, CellConstraints.DEFAULT, CellConstraints.FILL));

				//======== panel2 ========
				{
					panel2.setOpaque(false);
					panel2.setLayout(new FormLayout(
						new ColumnSpec[] {
							FormFactory.DEFAULT_COLSPEC,
							FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
							FormFactory.DEFAULT_COLSPEC
						},
						RowSpec.decodeSpecs("default")));

					//---- restrictionsApply2 ----
					restrictionsApply2.setText("Internal Only");
					restrictionsApply2.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					restrictionsApply2.setOpaque(false);
					restrictionsApply2.setText(ATFieldInfo.getLabel(Resources.class, Resources.PROPERTYNAME_INTERNAL_ONLY));
					panel2.add(restrictionsApply2, cc.xy(1, 1));

					//---- restrictionsApply ----
					restrictionsApply.setText("Restrictions Apply");
					restrictionsApply.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
					restrictionsApply.setOpaque(false);
					restrictionsApply.setText(ATFieldInfo.getLabel(Resources.class, ArchDescription.PROPERTYNAME_RESTRICTIONS_APPLY));
					panel2.add(restrictionsApply, cc.xy(3, 1));
				}
				panel17.add(panel2, cc.xy(1, 13));
			}
			panel13.add(panel17, cc.xywh(1, 1, 1, 1, CellConstraints.FILL, CellConstraints.DEFAULT));
		}
		add(panel13, cc.xywh(5, 1, 1, 1, CellConstraints.FILL, CellConstraints.DEFAULT));
		// JFormDesigner - End of component initialization  //GEN-END:initComponents
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner non-commercial license
	private JPanel panel16;
	private JPanel panel19;
	private JLabel label_resourcesLevel;
	public JComboBox resourcesLevel;
	private JLabel label_otherLevel;
	public JTextField resourcesOtherLevel;
	private JLabel label_resourcesTitle;
	private JScrollPane scrollPane2;
	public JTextArea resourcesTitle;
	private JPanel tagApplicatorPanel;
	public JComboBox insertInlineTag;
	private JLabel label_repositoryName4;
	private JScrollPane scrollPane8;
	private DomainSortableTable dateTable;
	private JPanel panel22;
	private JButton addDate;
	private JButton removeDate;
	private JPanel panel1;
	private JLabel label_resourcesLanguageCode;
	public JComboBox resourcesLanguageCode;
	private JLabel label_resourcesLanguageNote;
	private JScrollPane scrollPane423;
	public JTextArea resourcesLanguageNote;
	private JPanel panel6;
	private JLabel label_agreementReceived2;
	public JTextField repositoryName;
	private JButton changeRepositoryButton;
	private JSeparator separator2;
	private JPanel panel13;
	private JPanel panel17;
	private JPanel panel12;
	private JLabel label_resourceIdentifier1;
	public JTextField resourceIdentifier1;
	public JTextField resourceIdentifier2;
	public JTextField resourceIdentifier3;
	public JTextField resourceIdentifier4;
	private JPanel panel42;
	private JPanel panel43;
	private JLabel OtherAccessionsLabel;
	private JScrollPane scrollPane4;
	private DomainSortableTable accessionsTable;
	private JLabel label_repositoryName5;
	private JScrollPane scrollPane9;
	private DomainSortableTable physicalDescriptionsTable;
	private JPanel panel23;
	private JButton addPhysicalDescription;
	private JButton removePhysicalDescription;
	private JPanel panel39;
	private JPanel panel40;
	private JLabel label1;
	private JScrollPane scrollPane6;
	private DomainSortableTable instancesTable;
	private JPanel panel29;
	private JButton addInstanceButton;
	private JButton removeInstanceButton;
	private JPanel panel2;
	public JCheckBox restrictionsApply2;
	public JCheckBox restrictionsApply;
	// JFormDesigner - End of variables declaration  //GEN-END:variables
    private JPanel panel20;
    private JPanel panel21;
    //private JScrollPane scrollPane423;
    private JLabel ExtentNumberLabel2;
    private JLabel labelExtentNumber;
    public JFormattedTextField extentNumber;
    public JComboBox extentType;
    private JLabel labelExtent;
    public JTextArea containerSummary;
    private JPanel panelPhysDescr;
    // put back the original date panel (not multiple dates)
    private JPanel panel4;
    private JPanel panel5;
    private JLabel label_dateExpression;
    public JTextField dateExpression;
    private JLabel Date1Label;
    private JLabel label_date1Begin;
    public JFormattedTextField date1Begin;
    private JLabel label_date1End;
    public JFormattedTextField date1End;
    private JLabel BulkDatesLabel;
    private JLabel label_bulkDateBegin;
    public JFormattedTextField bulkDateBegin;
    private JLabel label_bulkDateEnd;
    public JFormattedTextField bulkDateEnd;

    private JTabbedPane tabbedPane9;    

	public void setModel(Resources resourcesModel) {
		this.resourceModel = resourcesModel;
		System.out.println("Resource set model: " + Integer.toHexString(System.identityHashCode(this.resourceModel)));
		dateTable.updateCollection(this.resourceModel.getArchDescriptionDates());
		physicalDescriptionsTable.updateCollection(this.resourceModel.getPhysicalDesctiptions());
		instancesTable.updateCollection(this.resourceModel.getInstances());
		accessionsTable.updateCollection(resourcesModel.getAccessions());
		
		setRepositoryText(this.resourceModel);

	}
	
}
