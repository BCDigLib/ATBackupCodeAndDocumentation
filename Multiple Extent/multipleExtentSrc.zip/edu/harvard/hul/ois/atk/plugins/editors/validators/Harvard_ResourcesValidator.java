
/**********************************************************************
 * Copyright (c) 2001 by the President and Fellows of Harvard College
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 *
 * Contact information
 *
 * Office for Information Systems
 * Harvard University Library
 * Harvard University
 * Cambridge, MA  02138
 * (617)495-3724
 * hulois@hulmail.harvard.edu
 *
 * This package is based heavily on BYU multiple-extent plugin package for ATK, customized for Harvard University
 *
 */

package edu.harvard.hul.ois.atk.plugins.editors.validators;

import org.archiviststoolkit.model.Accessions;
import org.archiviststoolkit.model.Resources;
import org.archiviststoolkit.util.ATPropertyValidationSupport;
import com.jgoodies.validation.ValidationResult;
import com.jgoodies.validation.util.ValidationUtils;

import edu.byu.plugins.editors.validators.BYU_ResourcesValidator;

public class Harvard_ResourcesValidator extends BYU_ResourcesValidator {

	// Instance Creation ******************************************************

	/**
	 * Constructs an validator
	 *
	 * @param accession the accession to be validated
	 */
	public Harvard_ResourcesValidator(Accessions accession) {
		this.objectToValidate = accession;
	}

	public Harvard_ResourcesValidator() {
	}


	// Validation *************************************************************

	/**
	 * Validates this Validator's Order and returns the result
	 * as an instance of {@link com.jgoodies.validation.ValidationResult}.
	 *
	 * @return the ValidationResult of the accession validation
	 */
	public ValidationResult validate() {

		Resources modelToValidate = (Resources)objectToValidate;

		ATPropertyValidationSupport support =
				new ATPropertyValidationSupport(modelToValidate, "Resources");

		if (ValidationUtils.isBlank(modelToValidate.getResourceIdentifier1()))
			support.addError("Resource Identifier", "is mandatory");

		if (ValidationUtils.isBlank(modelToValidate.getLevel()))
			support.addError("Level", "is mandatory");

		if (ValidationUtils.isBlank(modelToValidate.getTitle()))
			support.addError("Title", "is mandatory");

		if (ValidationUtils.isBlank(modelToValidate.getLanguageCode()))
			support.addError("Language Code", "is mandatory");

		//at least one date record is required
/*
		if (modelToValidate.getArchDescriptionDates().size() == 0)
			support.addError("At least one date record", "is mandatory");
*/         

		//at least one date record is required
/*
		if (modelToValidate.getPhysicalDesctiptions().size() == 0)
			support.addError("At least one physical description record", "is mandatory");
*/
        if (ValidationUtils.isBlank(modelToValidate.getExtentType()))
			support.addError("Extent Type", "is mandatory");

		if (modelToValidate.getExtentNumber() == null ||
				modelToValidate.getExtentNumber() == 0)
			support.addError("Extent", "is mandatory");
        
		//repository is manditory
		if (modelToValidate.getRepository() == null)
			support.addError("Repository", "is mandatory");

		checkForStringLengths(modelToValidate, support);

		return support.getResult();
	}
}
